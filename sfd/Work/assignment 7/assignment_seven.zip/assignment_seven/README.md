# Assignment seven

## Description

Module 7

## Authors

- Developer 1: Thomas Littleton
- Developer 2: Sandeep Kaur
- Developer 3: Karmjeet Kaur

## Assignment

In this capstone project, you will work in a group to develop a Python
application that intakes, processes, and outputs financial transaction data.
This project will give you the opportunity to practice essential skills for
a professional software developer, such as collaborative development,
effective communication, and adhering to industry standards.
