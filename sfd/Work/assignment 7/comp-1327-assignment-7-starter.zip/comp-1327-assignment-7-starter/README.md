# [Project Name]

## Description

[Provide the module number to which the project applies]

## Authors

- Developer 1: {Enter Student Name Here}
- Developer 2: {Enter Student Name Here}
- Developer 3: {Enter Student Name Here}

## Assignment

[Indicate the name and description of the assignment the project is related to]
