﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace steinbachBus
{
    public partial class Form1 : Form
    {
        //cords cordless = new cords();
        //cordless.
        
        enum GamePieces { road = 0, bus = 1, stop = 2, busAtStop = 3, accident = 4}

        Size gridSize = new Size(50,50);
        Size cellSize = new Size(20, 20); 
        bool simpleGraphics = true;
        Bitmap graphicBits = new Bitmap(typeof(Form1), "SteinbachBusIconsPixel.png");
        Bitmap simpleGraphicBits = new Bitmap(typeof(Form1), "SteinbachBusIconsPixel.png");
        Bitmap busGraphicBits = new Bitmap(typeof(Form1), "SteinbachBusTopDown.png");
        int busImageIndex;
        Point workerLocation = new Point(0, 0);
        int level = 1;
        int[,] gameData = new int[50,50];
        GamePieces[,] savedState;

        Stack<GamePieces[,]> savedStateHistory = new Stack<GamePieces[,]>();
        Stack<Point> savedWorkerLocation = new Stack<Point>();
        Stack<GamePieces[,]> savedStatesForRedo = new Stack<GamePieces[,]>();
        Stack<Point> savedWorkerLocForRedo = new Stack<Point>();
        List<Point> stopsClicked = new List<Point>();

        //int[,] accessibleCoords = ToStringCords();

        Rectangle busStop;
        Rectangle busRect;
        bool passengersAtStop = false;
        bool testBool = false;
        bus busPoints = new bus();
        Point currentPoint = new Point(0, 0);

        int busStopCount = 2;

        int numMoves = 0;


        int[,] line1 = { { 0, 3 }, { 5, 12 }, { 781, 1 }, { 8, 88 } };
        int[,] line2 = { { 0, 3 }, { 5, 12 }, { 781, 1 } };
        int[,] line3 = { { 0, 3 }, { 5, 12 }, { 781, 1 } };
        int[,] line4 = { { 0, 3 }, { 5, 12 }, { 781, 1 } };
        int[,] line5 = { { 0, 3 }, { 5, 12 }, { 781, 1 } };
        int[,] line6 = { { 0, 3 }, { 5, 12 }, { 781, 1 } };
        int[,] line7 = { { 0, 3 }, { 5, 12 }, { 781, 1 } };
        int[,] line8 = { { 0, 3 }, { 5, 12 }, { 781, 1 } };
        int lineSelected = 0;
        int xCoordinate = -1;
        int yCoordinate = -1;
        cords cordsclass = new cords();
        Point tempPoint = new Point(0, 0);


        

        //save number for locations in save.txt
        int savefile;
        int saveNumber;
        int saveLength;
        int saveRead;

        //numbers that we have to change in the game
        int numStops = 2;
        int trafic;
        int construction;

        //
        int showMap;

        private void SetCell(int x, int y, char character)
        {

        }

        public Form1()
        {
            InitializeComponent();
            //GetRand();
            Console.WriteLine(xCoordinate + "    " + yCoordinate);
        }
        
        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        public void Form1_Paint(object sender, PaintEventArgs e)
        {
            
            e.Graphics.TranslateTransform(0, menuStrip1.Height);
            int imageIndex = 0;
            //vertical lines
            for (int i = 0; i < gridSize.Width; i++)
            {
                e.Graphics.DrawLine(Pens.Black, i * cellSize.Width, 0, i * cellSize.Width, ClientRectangle.Bottom);
            }
            //horizontal lines
            for (int i = 0; i < gridSize.Height; i++)
            {
                e.Graphics.DrawLine(Pens.Black, 0, i * cellSize.Height, ClientRectangle.Right, i * cellSize.Height);
            }

            for (int i = 0; i < 49; i++)
            {
                for (int j = 0; j < 49; j++)
                {
                    try
                    {
                    }
                    catch
                    {

                    }
                    try
                    {
                        gameData[i, j] = 0;

                    }
                    catch
                    {
                        Console.WriteLine("err at" + i + "/" + j);
                    }
                }
            }
            for (int i = 0; i < 736; i++)
            {
                    gameData[cordsclass.coordinates[i, 0], cordsclass.coordinates[i, 1]] = 4;
            }
            for(int eux = 0;eux< numStops;eux++)
            {
                Random rend = new Random();
                Random rnda = new Random(eux+ rend.Next(1, 2000));
                int randa = Convert.ToInt16(736*(rnda.NextDouble())- (736 * (rnda.NextDouble())%1));
                gameData[cordsclass.coordinates[randa, 0], cordsclass.coordinates[randa, 1]] = 2;
                Console.WriteLine("set " + cordsclass.coordinates[randa, 0] + "/" + cordsclass.coordinates[randa, 1] + " to bus stop " + eux);
                busStopCount = 2;
            }



            if (showMap == 1)
            {

                for (int i = 0; i < gridSize.Width; i++)
                {
                    for (int j = 0; j < gridSize.Height; j++)
                    {
                        Rectangle srcRect = new Rectangle(imageIndex * cellSize.Width, 0, cellSize.Width, cellSize.Height);
                        Rectangle destRect = new Rectangle(i * cellSize.Width, j * cellSize.Height, cellSize.Width, cellSize.Height);
                        Rectangle busSrcRect = new Rectangle(busImageIndex * cellSize.Width, 0, cellSize.Width, cellSize.Height);
                        busRect = new Rectangle(currentPoint.X,currentPoint.Y,cellSize.Width,cellSize.Height);
                        //gamedata = 4 for bus stop, 3 for red pin, 2 for gold pin, 1 for bus, 0 for road
                        if (gameData[i, j] == 4)
                        {
                            //ImageIndex = 0 for the bus stop, 1 for red pin, 2 for gold pin, 3 for road
                            imageIndex = 3;
                            if (testBool == true)
                            {
                                imageIndex = 2;
                            }
                            srcRect = new Rectangle(imageIndex * cellSize.Width, 0, cellSize.Width, cellSize.Height);
                            e.Graphics.DrawImage(graphicBits, destRect, srcRect, GraphicsUnit.Pixel);
                            /*if (passengersAtStop == true)
                            {
                                imageIndex = 1;
                                //determine if the bus stop is an important stop
                                Rectangle tempDest = new Rectangle(destRect.X, destRect.Y - destRect.Height, destRect.Width, destRect.Height);
                                e.Graphics.DrawImage(graphicBits, tempDest, srcRect, GraphicsUnit.Pixel);
                            }*/


                        }
                        if (gameData[i, j] == 2)
                        {
                            //ImageIndex = 0 for the bus stop, 1 for red pin, 2 for gold pin, 3 for road
                            imageIndex = 0;
                            srcRect = new Rectangle(imageIndex * cellSize.Width, 0, cellSize.Width, cellSize.Height);
                            e.Graphics.DrawImage(graphicBits, destRect, srcRect, GraphicsUnit.Pixel);
                            /*if (passengersAtStop == true)
                            {
                                imageIndex = 1;
                                //determine if the bus stop is an important stop
                                Rectangle tempDest = new Rectangle(destRect.X, destRect.Y - destRect.Height, destRect.Width, destRect.Height);
                                e.Graphics.DrawImage(graphicBits, tempDest, srcRect, GraphicsUnit.Pixel);
                            }*/


                        }

                        if (true)
                        {
                            //gameData[i,j] == 1
                            busImageIndex = 0;
                            e.Graphics.DrawImage(busGraphicBits, busRect, busSrcRect, GraphicsUnit.Pixel);
                        }

                    }
                }
            }

            if (showMap == 0)
            {

            }
            

        }


        public void import()
        {

            string fileName = @"../../save.txt";


            string[] lines = File.ReadAllLines(fileName);

              
            Console.WriteLine(string.Join(Environment.NewLine, lines));

        }

        public void saves()
        {
            //ExportFile();
            
            string fileName = @"../../save.txt";
            string[] lines = File.ReadAllLines(fileName);

            //StreamReader saveRead = new StreamReader("../../save.txt");
            //string line2s = File.ReadAllText("../../save.txt");
            //string lineoftext;
            //lineoftext = saveRead.Read();
            //string lineofteXT = File.ReadAllText("../../save.txt");
            //lineoftext = 1000;
            //Console.Write(lineofteXT[1, 9]+"hi");
            //Console.WriteLine([1] + " lineof text");
            Random rnde = new Random();
            int rande = rnde.Next(0, 736);
            //saveNumber = savefile * 10;
            //Console.WriteLine(savefile * 10 == saveNumber);
            //Console.WriteLine(saveNumber + " save file number");
            //Console.WriteLine("save number " + savefile);
            //Console.WriteLine("Ansd  ");
            //Console.WriteLine(lines[9]);
            //savenum = (numStops * saveFive);
            //Console.WriteLine(lines[saveNumber] + " line1");


            saveLength = 10;
            //to get the file save line
            saveNumber = savefile * 10;
            saveRead = saveNumber + saveLength;
                
            Console.WriteLine(lines[saveNumber]);
            
















            /*
            for (int i= 2; i < 8; i++)
            {
                try
                {
                    Console.WriteLine(lines[1001]);

                }
                catch
                {
                    Console.WriteLine("fail"); 
                }
            }
            */
            
        }

        public void ExportFile()
        {
            Random rnd = new Random();
            int rand = rnd.Next(0, 117843647);
            int saveNumber = 1000;
            //for the save you take the button number and * by save number
            int stopsph = 0;
            
            string[] lines = File.ReadAllLines("../../save.txt");
            string fullPath = "../../save.txt";

            using (StreamWriter writer = new StreamWriter(fullPath))
            {
                //writer.WriteLine("num stops " + numStops);
                writer.WriteLine("Save number " + saveNumber);
                writer.WriteLine(stopsph);
                
                writer.WriteLine("Line 1:");
                for (int i = 0; i < 9; i++)
                {
                    try
                    {
                        writer.WriteLine(line1[i, 0] + "    " + line1[i, 1]);
                    }
                    catch
                    {
                        writer.WriteLine(" ");
                    }
                }
                writer.WriteLine("Line 2:");
                for (int i = 0; i < 9; i++)
                {
                    try
                    {

                        writer.WriteLine(line2[i, 0] + "    " + line1[i, 1]);
                    }
                    catch
                    {
                        writer.WriteLine("");
                    }
                }
                
            }
        }

        public int GetFastestLine(int a1, int a2, int b1, int b2)
        {
            int n = 0;
            string x = "";
            int xAbs = (b1 - a1); //8
            int yAbs = (b2 - a2); //1

            if (Math.Abs(xAbs) > Math.Abs(yAbs))
            {
                if (yAbs == 0)
                {
                }
                else
                {
                    n = xAbs / yAbs;
                    //for every x, travel n px y down 
                    x = " down";
                }
            }
            else
            {
                if (xAbs == 0)
                {
                }
                else
                {
                    n = yAbs / xAbs;
                    //for every y, travel n px x to the right
                    x = " right";
                }
            }
            return n;
        }

        

        public void map()
        {

            /*
             Feel free to comment this all out for the time being if it causes errors 

            Below code was based on a text file containing coordinates

            StreamReader mapCoordinates = new StreamReader(".. / .. / save.txt");
            while (!mapCoordinates.EndOfStream)
            {
                lineOfText = mapCoordinates.ReadLine();
                try
                {
                    if (lineOfText[0].Equals('('))
                    {
                        if (lineOfText[4].Equals(')'))
                        {
                            tempPoint.X = lineOfText[1];
                            tempPoint.Y = lineOfText[3];
                            roadMap[tempPoint.X, tempPoint.Y] = 1; //1 means ‘road’ in this context
                        }
                        else if (lineOfText[5].Equals(')'))
                        {
                            if (lineOfText[2].Equals(','))
                            {
                                tempPoint.X = lineOfText[1];
                                tempPoint.Y = lineOfText[3] + lineOfText[4];
                                roadMap[tempPoint.X, tempPoint.Y] = 1;
                            }
                            else
                            {
                                tempPoint.X = lineOfText[1] + lineOfText[2];
                                tempPoint.Y = lineOfText[4];
                                roadMap[tempPoint.X, tempPoint.Y] = 1;
                            }
                        }
                        //what is the 5 and 3 for
                        //the position of the bracket character in the text file
                        //position 1 and 3 are the numbers that will be converted into coordinates
                        //checking for the position of the last bracket will make sure two digit numbers are converted properly
                        //are you going to do that for every point
                        //this should take care of the entire text file
                        //if goes to about the line of 740 or it takes up just one line
                        //I did not notice the coordinate array at the bottom of the file. Probably should've looked at the whole thing before starting this
                        //the ones going up and down are just a list up the ones going right and left are in a 2d array
                        else if (lineOfText[6].Equals(')'))
                        {
                            tempPoint.X = lineOfText[1] + lineOfText[2];
                            tempPoint.Y = lineOfText[4] + lineOfText[5];
                            roadMap[tempPoint.X, tempPoint.Y] = 1;
                        }

                    }
                }
                catch { }

                

            }
             */
            string lineOfText = null;
            
            int[,] roadMap = new int[Size.Width, Size.Height];
            //Elora have you started making assets yet?
            //I wasn't sure what exactly the map would end up looking like/what size or style it needs to be, but I can start on it right away
            //I can't see the design window, so what pixel size would you recommend? 
            //we are doing 50x50 pixles and there is nothing in the design thing right now
            //If I were to make an image it would stay the same size unless modified in the art program itself // ok
            //Elora 20x20 assets would be ideal. - Garrett and Thomas agree on this.
            //Sounds good. Just to clarify, there don't need to be any environment or building assets, just the bus and stuff?
            //do bus,stop,road?,important stops that is all that needs to get done

            for(int i = 0; i < Size.Width; i++)
            {
                for(int j = 0; j < Size.Height; j++)
                {
                    //if (roadMap[i,j] == )
                }
            }

            

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        public void save1_Click(object sender, EventArgs e)
        {
            
            savefile = 1;

        }

        public void save2_Click(object sender, EventArgs e)
        {
            
            savefile = 2;

        }

        private void start_Click(object sender, EventArgs e)
        {
            save1.Visible = false;
            save2.Visible = false;
            start.Visible = false;
            saves();
            showMap = 1;
            
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            busStop = new Rectangle(tempPoint.X, tempPoint.Y, cellSize.Width, cellSize.Height);
            //place code elsewhere to identify bus stop locations, check it here
            for(int i = 0; i < Size.Width; i++)
            {
                for(int j = 0; j < Size.Height; j++)
                {
                    if(e.X == i && e.Y == j)
                    {
                        if(i >= busStop.X && i<= busStop.X + busStop.Width)
                        {
                            if(j >= busStop.Y && j<= busStop.Y + busStop.Height)
                            {
                                //Will activate whatever code needed when the bus stop is clicked on
                                testBool = true;
                                if(passengersAtStop == true)
                                {
                                    passengersAtStop = false;
                                    BuildRoute();


                                }
                            }
                        }
                    }
                }
            }
            tempPoint.X = busStop.X;
            tempPoint.Y = busStop.Y;
            Invalidate();
        }

        private void BuildRoute()
        {
            for(int i = 0; i < numStops; i++)
            {
                stopsClicked.Add(tempPoint);
                busPoints.AddStopToEnd(stopsClicked.Last().X, stopsClicked.Last().Y);
            }
        }

        private void plusNumStops_Click(object sender, EventArgs e)
        {
            numStops++;
            Console.WriteLine(numStops +"hi");
            Invalidate();
        }

        private void lastNumStops_Click(object sender, EventArgs e)
        {
            numStops--;
            Console.WriteLine(numStops+"no");
            Invalidate();
        }
    }
}
