﻿namespace steinbachBus
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openSaveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.start = new System.Windows.Forms.Button();
            this.plusNumStops = new System.Windows.Forms.Button();
            this.minusNumStops = new System.Windows.Forms.Button();
            this.minusConstruction = new System.Windows.Forms.Button();
            this.plusTrafic = new System.Windows.Forms.Button();
            this.minusTrafic = new System.Windows.Forms.Button();
            this.nextSave = new System.Windows.Forms.Button();
            this.lastSave = new System.Windows.Forms.Button();
            this.plusConstruction = new System.Windows.Forms.Button();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1147, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saveFileToolStripMenuItem,
            this.openSaveToolStripMenuItem,
            this.quitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
            this.fileToolStripMenuItem.Text = "file";
            // 
            // saveFileToolStripMenuItem
            // 
            this.saveFileToolStripMenuItem.Name = "saveFileToolStripMenuItem";
            this.saveFileToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.saveFileToolStripMenuItem.Text = "save file";
            this.saveFileToolStripMenuItem.Click += new System.EventHandler(this.saveFileToolStripMenuItem_Click);
            // 
            // openSaveToolStripMenuItem
            // 
            this.openSaveToolStripMenuItem.Name = "openSaveToolStripMenuItem";
            this.openSaveToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.openSaveToolStripMenuItem.Text = "open save";
            this.openSaveToolStripMenuItem.Click += new System.EventHandler(this.openSaveToolStripMenuItem_Click);
            // 
            // quitToolStripMenuItem
            // 
            this.quitToolStripMenuItem.Name = "quitToolStripMenuItem";
            this.quitToolStripMenuItem.Size = new System.Drawing.Size(127, 22);
            this.quitToolStripMenuItem.Text = "quit";
            this.quitToolStripMenuItem.Click += new System.EventHandler(this.quitToolStripMenuItem_Click);
            // 
            // start
            // 
            this.start.Location = new System.Drawing.Point(34, 60);
            this.start.Name = "start";
            this.start.Size = new System.Drawing.Size(75, 23);
            this.start.TabIndex = 3;
            this.start.Text = "start";
            this.start.UseVisualStyleBackColor = true;
            this.start.Click += new System.EventHandler(this.start_Click);
            // 
            // plusNumStops
            // 
            this.plusNumStops.Location = new System.Drawing.Point(1022, 44);
            this.plusNumStops.Name = "plusNumStops";
            this.plusNumStops.Size = new System.Drawing.Size(103, 23);
            this.plusNumStops.TabIndex = 4;
            this.plusNumStops.Text = "plus one bus stops";
            this.plusNumStops.UseVisualStyleBackColor = true;
            this.plusNumStops.Click += new System.EventHandler(this.plusNumStops_Click);
            // 
            // minusNumStops
            // 
            this.minusNumStops.Location = new System.Drawing.Point(1022, 78);
            this.minusNumStops.Name = "minusNumStops";
            this.minusNumStops.Size = new System.Drawing.Size(113, 23);
            this.minusNumStops.TabIndex = 5;
            this.minusNumStops.Text = "minus one bus stop";
            this.minusNumStops.UseVisualStyleBackColor = true;
            this.minusNumStops.Click += new System.EventHandler(this.minusNumStops_Click);
            // 
            // minusConstruction
            // 
            this.minusConstruction.Location = new System.Drawing.Point(1022, 153);
            this.minusConstruction.Name = "minusConstruction";
            this.minusConstruction.Size = new System.Drawing.Size(127, 23);
            this.minusConstruction.TabIndex = 7;
            this.minusConstruction.Text = "minus one construction";
            this.minusConstruction.UseVisualStyleBackColor = true;
            this.minusConstruction.Click += new System.EventHandler(this.minusConstruction_Click);
            // 
            // plusTrafic
            // 
            this.plusTrafic.Location = new System.Drawing.Point(1022, 203);
            this.plusTrafic.Name = "plusTrafic";
            this.plusTrafic.Size = new System.Drawing.Size(91, 23);
            this.plusTrafic.TabIndex = 8;
            this.plusTrafic.Text = "plus one trafic";
            this.plusTrafic.UseVisualStyleBackColor = true;
            this.plusTrafic.Click += new System.EventHandler(this.plusTrafic_Click);
            // 
            // minusTrafic
            // 
            this.minusTrafic.Location = new System.Drawing.Point(1022, 233);
            this.minusTrafic.Name = "minusTrafic";
            this.minusTrafic.Size = new System.Drawing.Size(91, 23);
            this.minusTrafic.TabIndex = 9;
            this.minusTrafic.Text = "minus one trafic";
            this.minusTrafic.UseVisualStyleBackColor = true;
            this.minusTrafic.Click += new System.EventHandler(this.minusTrafic_Click);
            // 
            // nextSave
            // 
            this.nextSave.Location = new System.Drawing.Point(354, 58);
            this.nextSave.Name = "nextSave";
            this.nextSave.Size = new System.Drawing.Size(75, 23);
            this.nextSave.TabIndex = 10;
            this.nextSave.Text = "next save";
            this.nextSave.UseVisualStyleBackColor = true;
            this.nextSave.Click += new System.EventHandler(this.nextSave_Click);
            // 
            // lastSave
            // 
            this.lastSave.Location = new System.Drawing.Point(354, 92);
            this.lastSave.Name = "lastSave";
            this.lastSave.Size = new System.Drawing.Size(75, 23);
            this.lastSave.TabIndex = 11;
            this.lastSave.Text = "last save";
            this.lastSave.UseVisualStyleBackColor = true;
            this.lastSave.Click += new System.EventHandler(this.lastSave_Click);
            // 
            // plusConstruction
            // 
            this.plusConstruction.Location = new System.Drawing.Point(1022, 124);
            this.plusConstruction.Name = "plusConstruction";
            this.plusConstruction.Size = new System.Drawing.Size(120, 23);
            this.plusConstruction.TabIndex = 12;
            this.plusConstruction.Text = "plus one construction";
            this.plusConstruction.UseVisualStyleBackColor = true;
            this.plusConstruction.Click += new System.EventHandler(this.plusConstruction_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1147, 961);
            this.Controls.Add(this.plusConstruction);
            this.Controls.Add(this.lastSave);
            this.Controls.Add(this.nextSave);
            this.Controls.Add(this.minusTrafic);
            this.Controls.Add(this.plusTrafic);
            this.Controls.Add(this.minusConstruction);
            this.Controls.Add(this.minusNumStops);
            this.Controls.Add(this.plusNumStops);
            this.Controls.Add(this.start);
            this.Controls.Add(this.menuStrip1);
            this.DoubleBuffered = true;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseUp);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Button start;
        private System.Windows.Forms.Button plusNumStops;
        private System.Windows.Forms.Button minusNumStops;
        private System.Windows.Forms.Button minusConstruction;
        private System.Windows.Forms.Button plusTrafic;
        private System.Windows.Forms.Button minusTrafic;
        private System.Windows.Forms.Button nextSave;
        private System.Windows.Forms.Button lastSave;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveFileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openSaveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quitToolStripMenuItem;
        private System.Windows.Forms.Button plusConstruction;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.Timer timer1;
    }
}

