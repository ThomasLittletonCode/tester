﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace steinbachBus
{
    internal class bus : cords
    {
        public int passengerCount = 0;
        public int passengerCountMax = 16;
        public int stopCount = 0;
        public int[,] stopList;
        public int AddStopToEnd (int x, int y)
        {
            stopList[stopList.Length,0] = x;
            stopList[stopList.Length,1] = y;
            return 0;
        }
        public int ClearLine()
        {
            for (int i = 0; i < 737; i++)
            {
                stopList[i, 0] = -1;
                stopList[i, 1] = -1;
            }
            return 0;
        }
    }
}
