﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace steinbachBus
{
    public partial class Form1 : Form
    {
        bool ranalready = false;
        enum GamePieces { road = 0, bus = 1, stop = 2, busAtStop = 3, accident = 4 }
        DateTime time = DateTime.Now;
        Size gridSize = new Size(50, 50);
        Size cellSize = new Size(20, 20);
        bool simpleGraphics = true;
        Bitmap graphicBits = new Bitmap(typeof(Form1), "SteinbachBusIconsPixel.png");
        Bitmap simpleGraphicBits = new Bitmap(typeof(Form1), "SteinbachBusIconsPixel.png");
        Bitmap busGraphicBits = new Bitmap(typeof(Form1), "SteinbachBusTopDown.png");
        int busImageIndex;
        Point workerLocation = new Point(0, 0);
        int level = 1;
        int[,] gameData = new int[50, 50];
        GamePieces[,] savedState;

        Stack<GamePieces[,]> savedStateHistory = new Stack<GamePieces[,]>();
        Stack<Point> savedWorkerLocation = new Stack<Point>();
        Stack<GamePieces[,]> savedStatesForRedo = new Stack<GamePieces[,]>();
        Stack<Point> savedWorkerLocForRedo = new Stack<Point>();
        List<Point> stopsClicked = new List<Point>();
        List<Point> orderedStops = new List<Point>();

        //int[,] accessibleCoords = ToStringCords();

        Rectangle busStop;
        Rectangle busRect;
        bool passengersAtStop = false;
        bool testBool = false;
        Bus busPoints = new Bus();
        Point currentPoint = new Point(0, 0);
        Point velocity = new Point(0, 0);
        int busSpeed = 5;
        bool rightDir = false;
        bool leftDir = false;
        bool upDir = false;
        bool downDir = false;
        bool startDriving = true;

         

int[,] line1 = { };
        int[,] line2 = { };
        int[,] line3 = { };
        int[,] line4 = { };
        int[,] line5 = { };
        int[,] line6 = { };
        int[,] line7 = { };
        int[,] line8 = { };
        int lineSelected = 0;
        int xCoordinate = -1;
        int yCoordinate = -1;
        cords cordsclass = new cords();
        Point tempPoint = new Point(0, 0);

        //to change what save it is going to go to
        int changeSave = 1;
        //save number for locations in save.txt
        //why save file is one is because it is 0 at first and since i need change save to be 1 so you do not use save 0 it will start it at 2 or 0 if it was not for it
        //being a 1 as when you start it will be at 0 first or if you move you save number up one it will be at 2 as change save will be at 2

        //save number for locations in save.txt
        int savefile = 1;
        int saveNumber;
        int saveLength;
        int saveRead;
        int fileSize;
        int max;

        //this is to show and hide the text
        bool showText = true;

        //numbers that we have to change in the game
        int numStops = 2;
        int traffic = 2;
        int construction = 2;

        //for the location of the cords stored in the save file
        int cordSave;
        //for the space between the start of the save so i can have the values stored there
        int cordStart;
        //for if i want later for the end of the cords for that save
        int cordEnd;

        //this was going to be for something but do not remember 

        //this is to show or hide the map
        int showMap;

        public Form1()
        {
            InitializeComponent();
            //GetRand();
            Console.WriteLine(xCoordinate + "    " + yCoordinate);
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            stopsClicked.Add(tempPoint);
            stopsClicked.Add(currentPoint);
            ClosestStop(stopsClicked); //For testing; will be removed later
        }



        public void Form1_Paint(object sender, PaintEventArgs e)
        {
            //this is to show or hide the text
            //this shows the text
            if (showText == true)
            {
                //this is to show the text for if they are bellow the min or what number ther are
                //this is to show what number they are at for saves
                PointF pointsone = new PointF(200, 200);
                if (changeSave >= 1)
                {
                    FontFamily fontFamily = new FontFamily("arial");
                    Font arial = new Font(fontFamily, 60, FontStyle.Regular, GraphicsUnit.Pixel);
                    Brush textBrush = new SolidBrush(Color.Blue);
                    e.Graphics.DrawString("your save number is " + savefile, arial, textBrush, pointsone);
                }
                //this is to show that they are bellow the min
                if (changeSave < 1)
                {
                    FontFamily fontFamily = new FontFamily("arial");
                    Font arial = new Font(fontFamily, 60, FontStyle.Regular, GraphicsUnit.Pixel);
                    Brush textBrush = new SolidBrush(Color.Blue);
                    e.Graphics.DrawString("you tried to go bellow the minimum number of saves ", arial, textBrush, pointsone);
                }
            }
            else { }

            //this is to show the map and the stuff on the map
            if (showMap == 1)
            {
                TestDrive(); //To test the movement function
                e.Graphics.TranslateTransform(0, menuStrip1.Height);
                int imageIndex = 0;
                //vertical lines
                for (int i = 0; i < gridSize.Width; i++)
                {
                    e.Graphics.DrawLine(Pens.Black, i * cellSize.Width, 0, i * cellSize.Width, ClientRectangle.Bottom);
                }
                //horizontal lines
                for (int i = 0; i < gridSize.Height; i++)
                {
                    e.Graphics.DrawLine(Pens.Black, 0, i * cellSize.Height, ClientRectangle.Right, i * cellSize.Height);
                }
                //makes a 2D array for bus stop data that is empty
                int[,] busStopRand = new int[150, 150];
                //makes a 2D array for construction data that is empty
                int[,] constructionRand = new int[150, 150];
                //makes a 2D array for traffic data that is empty
                int[,] trafficRand = new int[150, 150];

                Random randomyea = new Random();

                //something to do with drawing the stop
                for (int i = 0; i < 50; i++)
                {
                    for (int j = 0; j < 50; j++)
                    {
                        try
                        {
                            gameData[i, j] = 0;

                        }
                        catch
                        {
                            Console.WriteLine("err at" + i + "/" + j);
                        }
                    }
                }
                //runs a loop 100 times
                if (!ranalready)
                {
                    for (int sx = 0; sx < 100; sx++)
                    {
                        int raod001 = Convert.ToInt16(737 * (randomyea.NextDouble()) - (737 * (randomyea.NextDouble()) % 1));
                        try
                        {
                            busStopRand[sx, 0] = cordsclass.coordinates[raod001, 0];
                        }
                        catch
                        {

                        }
                        try
                        {
                            busStopRand[sx, 1] = cordsclass.coordinates[raod001, 1];
                        }
                        catch
                        {

                        }
                    }
                    for (int sy = 0; sy < 100; sy++)
                    {
                        int raod002 = Convert.ToInt16(737 * (randomyea.NextDouble()) - (737 * (randomyea.NextDouble()) % 1));
                        try
                        {
                            constructionRand[sy, 0] = cordsclass.coordinates[raod002, 0];
                        }
                        catch
                        {

                        }
                        try
                        {
                            constructionRand[sy, 1] = cordsclass.coordinates[raod002, 1];
                        }
                        catch
                        {

                        }
                    }
                    for (int sz = 0; sz < 100; sz++)
                    {
                        int raod003 = Convert.ToInt16(737 * (randomyea.NextDouble()) - (737 * (randomyea.NextDouble()) % 1));
                        try
                        {
                            trafficRand[sz, 0] = cordsclass.coordinates[raod003, 0];
                        }
                        catch
                        {

                        }
                        try
                        {
                            trafficRand[sz, 1] = cordsclass.coordinates[raod003, 1];
                        }
                        catch
                        {

                        }
                    }
                    ranalready = true;
                }
                for (int i = 0; i < 737; i++)
                {
                    gameData[cordsclass.coordinates[i, 0], cordsclass.coordinates[i, 1]] = 4;
                }
                Console.WriteLine(numStops+" eus "+construction+" aui "+ traffic);

                for (int eux = 0; eux < numStops; eux++)
                {
                    gameData[busStopRand[eux, 0], busStopRand[eux, 1]] = 2;
                }

                for (int aux = 0; aux < construction; aux++)
                {
                    gameData[constructionRand[aux, 0], constructionRand[aux, 1]] = 9;
                }

                for (int iux = 0; iux < traffic; iux++)
                {
                    gameData[trafficRand[iux, 0], trafficRand[iux, 1]] = 7;
                }

                for (int i = 0; i < 737; i++)
                {
                    if(gameData[cordsclass.coordinates[i, 0], cordsclass.coordinates[i, 1]] == 2|| gameData[cordsclass.coordinates[i, 0], cordsclass.coordinates[i, 1]] == 9||gameData[cordsclass.coordinates[i, 0], cordsclass.coordinates[i, 1]] == 7)
                    {
                        gameData[cordsclass.coordinates[i, 0], cordsclass.coordinates[i, 1]] = 4;
                    }
                }
                for (int i = 0; i < gridSize.Width; i++)
                {
                    for (int j = 0; j < gridSize.Height; j++)
                    {
                        Rectangle srcRect = new Rectangle(imageIndex * cellSize.Width, 0, cellSize.Width, cellSize.Height);
                        Rectangle destRect = new Rectangle(i * cellSize.Width, j * cellSize.Height, cellSize.Width, cellSize.Height);
                        Rectangle busSrcRect = new Rectangle(busImageIndex * cellSize.Width, 0, cellSize.Width, cellSize.Height);
                        busRect = new Rectangle(currentPoint.X, currentPoint.Y, cellSize.Width, cellSize.Height);
                        //gamedata = 4 for bus stop,
                        if (gameData[i, j] == 4)
                        {
                            //ImageIndex = 0 for the bus stop, 1 for red pin, 2 for gold pin, 3 for road, 
                            imageIndex = 3;
                            
                            srcRect = new Rectangle(imageIndex * cellSize.Width, 0, cellSize.Width, cellSize.Height);
                            e.Graphics.DrawImage(graphicBits, destRect, srcRect, GraphicsUnit.Pixel);
                        }
                        if (gameData[i, j] == 2)
                        {
                            //ImageIndex = 0 for the bus stop, 1 for red pin, 2 for gold pin, 3 for road
                            imageIndex = 0;
                            srcRect = new Rectangle(imageIndex * cellSize.Width, 0, cellSize.Width, cellSize.Height);
                            e.Graphics.DrawImage(graphicBits, destRect, srcRect, GraphicsUnit.Pixel);
                        }
                        if (gameData[i, j] == 7)
                        {
                            //ImageIndex = 0 for the bus stop, 1 for red pin, 2 for gold pin, 3 for road
                            imageIndex = 4;
                            srcRect = new Rectangle(imageIndex * cellSize.Width, 0, cellSize.Width, cellSize.Height);
                            e.Graphics.DrawImage(graphicBits, destRect, srcRect, GraphicsUnit.Pixel);
                        }
                        if (gameData[i, j] == 9)
                        {
                            //ImageIndex = 0 for the bus stop, 1 for red pin, 2 for gold pin, 3 for road
                            imageIndex = 5;
                            srcRect = new Rectangle(imageIndex * cellSize.Width, 0, cellSize.Width, cellSize.Height);
                            e.Graphics.DrawImage(graphicBits, destRect, srcRect, GraphicsUnit.Pixel);
                        }

                        if (true)
                        {
                            //gameData[i,j] == 1
                            busImageIndex = 0;
                            e.Graphics.DrawImage(busGraphicBits, busRect, busSrcRect, GraphicsUnit.Pixel);
                        }
                    }
                }
            }
            //this is to hide the map and the stuff that is on it
            if (showMap == 2) { }
        }

        public void import()
        {
            string fileName = @"../../save.txt";
            string[] lines = File.ReadAllLines(fileName);
            Console.WriteLine(string.Join(Environment.NewLine, lines));
        }

        public void saves()
        {
            string fileName = @"../../save.txt";
            string[] lines = File.ReadAllLines(fileName);
            //string line = File.ReadLines("../../save.txt");
            //StreamReader line = new StreamReader("../../save.txt");
            //string line2s = File.ReadAllText("../../save.txt");
            string lineoftext;
            //lineoftext = line.Read("../../save.txt");
            string lineofteXT = File.ReadAllText("../../save.txt");
            //lineoftext = 1000;
            //Console.Write(lineofteXT[1, 9]+"hi");
            //Console.WriteLine([1] + " lineof text");
            Random rnde = new Random();
            int rande = rnde.Next(0, 737);

            //the length of how how long the save is going to be
            saveLength = 10;
            //on how big the file can be
            //to get the file save line

            //where it will save
            saveNumber = savefile * saveLength;
            //to get how long the save is so where it will end
            saveRead = saveNumber + saveLength;

            int fix;
            fix = 1;

            
            
            /*

            if (savefile >= 1)
            {
                //get the construction number
                construction = Convert.ToInt32(lines[savefile + (fix) + (1)]);
                //get the num stops number
                numStops = Convert.ToInt32(lines[savefile + (fix) + (2)]);
                //get the traffic number
                traffic = Convert.ToInt32(lines[savefile + (fix) + (3)]);
            }

            else
            {
                //get the construction number
                construction = Convert.ToInt32(lines[savefile + (1)]);
                //get the num stops number
                numStops = Convert.ToInt32(lines[savefile + (2)]);
                //get the traffic number
                traffic = Convert.ToInt32(lines[savefile + (3)]);
            }
            */
            
            for(int i = 0; i < saveNumber; i++)
            {
                try
                {
                    Console.WriteLine(lines[i] + " save file");
                }
                catch { }
                
            }
            

        }

        public void ExportFile()
        {
            cordStart = 4;

            cordSave = saveNumber + cordStart;
            Random rnd = new Random();
            int rand = rnd.Next(0, 117843647);




            string[] linest = File.ReadAllLines("../../save.txt");
            //string fullPath = "../../save.txt";
            
            using (StreamWriter writer = new StreamWriter("../../save.txt"))
            {

                //saves();
                max = Convert.ToInt16 (linest[0]);
                Console.WriteLine(max + "hi");
                
                if(saveNumber < max)
                {
                    for (int i = 0; i < saveNumber; i++)
                    {
                        if(i <= saveNumber)
                        {
                            try
                            {
                                writer.WriteLine(linest[i] + "this is the end of the file number one");
                            }
                            catch { }
                        }

                        if (i > saveRead)
                        {
                            try
                            {
                                writer.WriteLine(linest[i] + "this is the end of the file number four");
                            }
                            catch { }
                        }

                    }
                }

                if (saveNumber > max)
                {
                    for (int i = 0; i < saveNumber; i++)
                    {
                        if (i < saveNumber)
                        {
                            try
                            {
                                writer.WriteLine(linest[i] + "this is the end of the file number three");
                            }
                            catch { }



                        }
                        
                        if(i >= saveNumber)
                        {
                            writer.WriteLine(numStops + traffic + construction);
                        }

                    }
                }


                //writer.Write()
                /*
                for (int i = 0; i < saveNumber; i++)
                {

                    try
                    {
                        writer.WriteLine(linest[i] + "this is the end of the file");
                    }
                    catch { }
                    
                    
                }
                */







                /*
                writer.WriteLine("Save #" + savefile);
                for (int f = 0; f < saveNumber - 1; f++)
                {
                    writer.WriteLine(" ");
                }
                for (int x = 0; x < 49; x++)
                {

                    for (int y = 0; y < 49; y++)
                    {
                        string aeiou = "err";
                        if (gameData[x, y] == 2)
                        {
                            aeiou = "bus stop";
                        }
                        else if (gameData[x, y] == 9)
                        {
                            aeiou = "construction";
                        }
                        else if (gameData[x, y] == 7)
                        {
                            aeiou = "traffic";
                        }
                        if (gameData[x, y] != 4 && gameData[x, y] != 0)
                        {
                            writer.WriteLine(x + " " + y + "  " + aeiou);
                        }
                    }
                }
                */
            }
        }

        public void writeCoords()
        {
            for (int x = 0; x < 49; x++)
            {

                for (int y = 0; y < 49; y++)
                {
                    string aeiou = "err";
                    if (gameData[x, y] == 2)
                    {
                        aeiou = "bus stop";
                    }
                    else if (gameData[x, y] == 9)
                    {
                        aeiou = "construction";
                    }
                    else if (gameData[x, y] == 7)
                    {
                        aeiou = "traffic";
                    }
                    if (gameData[x, y] != 4 && gameData[x, y] != 0)
                    {
                        writer.WriteLine(x + " " + y + "  " + aeiou);
                    }
                }
            }

            return;
        }

        public int GetFastestLine(int a1, int a2, int b1, int b2)
        {
            //a1 & b1 are xy for first point
            //a2 & b2 are xy for second point
            int n = 0;
            string x = "";
            int xAbs = (b1 - a1); //8
            int yAbs = (b2 - a2); //1

            if (Math.Abs(xAbs) > Math.Abs(yAbs))
            {
                if (yAbs == 0)
                {
                }
                else
                {
                    n = xAbs / yAbs;
                    //for every x, travel n px y down 
                    x = " down";
                }
            }
            else
            {
                if (xAbs == 0)
                {
                }
                else
                {
                    n = yAbs / xAbs;
                    //for every y, travel n px x to the right
                    x = " right";
                }
            }
            return n;
        }

        public void map()
        {
            string lineOfText = null;

            int[,] roadMap = new int[Size.Width, Size.Height];

            for (int i = 0; i < Size.Width; i++)
            {
                for (int j = 0; j < Size.Height; j++)
                {
                }
            }
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
        }

        private void Form1_MouseUp(object sender, MouseEventArgs e)
        {
            //busStop = new Rectangle(tempPoint.X, tempPoint.Y, cellSize.Width, cellSize.Height);
            //place code elsewhere to identify bus stop locations, check it here
            for (int i = 0; i < Size.Width; i++)
            {
                for (int j = 0; j < Size.Height; j++)
                {
                    
                    try
                    {
                        if (gameData[i, j] == 4)
                        {
                            busStop = new Rectangle(i, j, cellSize.Width, cellSize.Height);
                        }
                        if (gameData[e.X, e.Y] == 4)
                        {
                            tempPoint.X = busStop.X;
                            tempPoint.Y = busStop.Y;
                            BuildRoute();
                        }
                    }
                    catch
                    {

                    }
                }
            }
            
            
            //tempPoint.X = busStop.X;
            //tempPoint.Y = busStop.Y;
            Invalidate();
        }

        private void BuildRoute()
        {

            for (int i = 0; i < numStops; i++)
            {
                stopsClicked.Add(tempPoint);
                busPoints.AddStopToEnd(stopsClicked.Last().X, stopsClicked.Last().Y);
                Console.WriteLine("test " + GetFastestLine(currentPoint.X, stopsClicked.Last().X, currentPoint.Y, stopsClicked.Last().Y));
            }
            if (stopsClicked.Count == numStops)
            {
                //timer1.Enabled = true;

            }
        }


        private void start_Click(object sender, EventArgs e)
        {
            start.Visible = false;
            saves();
            showMap = 1;

            if (changeSave >= 1)
            {
                nextSave.Visible = false;
                lastSave.Visible = false;
                start.Visible = false;
                saves();
                showText = false;
            }
            else { }

            Invalidate();

        }

        private void plusNumStops_Click(object sender, EventArgs e)
        {
            numStops++;
            Console.WriteLine(numStops + " stops, " + construction + " constr and " + traffic + " traffic");
            Invalidate();
        }

        private void minusNumStops_Click(object sender, EventArgs e)
        {
            numStops--;
            Console.WriteLine(numStops + "no");
            Invalidate();
        }

        private void nextSave_Click(object sender, EventArgs e)
        {
            changeSave++;
            savefile = changeSave;
            Invalidate();
        }

        private void lastSave_Click(object sender, EventArgs e)
        {
            if (changeSave >= 1)
            {
                changeSave--;
                savefile = changeSave;
            }
            else { }
            Invalidate();
        }

        private void saveFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ExportFile();
        }

        private void openSaveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //this is for going back to the main menu
            //this is for showing the next save button
            nextSave.Visible = true;
            //this is for showing the last save button
            lastSave.Visible = true;
            //this is for showing the start button
            start.Visible = true;
            //this is to show the text
            showText = true;
            showMap = 2;
            Invalidate();
        }

        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //this is to quit the program
            Application.Exit();
        }

        private void plusConstruction_Click(object sender, EventArgs e)
        {
            construction++;
            Console.WriteLine(numStops + " stops, " + construction + " constr and " + traffic + " traffic");
            Invalidate();
        }

        private void minusConstruction_Click(object sender, EventArgs e)
        {
            construction--;
            Invalidate();
        }

        private void plusTrafic_Click(object sender, EventArgs e)
        {
            traffic++;
            Console.WriteLine(numStops + " stops, " + construction + " constr and " + traffic + " traffic");
            Invalidate();
        }

        private void minusTrafic_Click(object sender, EventArgs e)
        {
            traffic--;
            Invalidate();
        }

        private void ClosestStop(List<Point> stops)
        {
            //stops.Sort();
            Console.WriteLine("Stoplist " + stops.Count);
            for (int i = 0; i < stops.Count; i++)
            {
                
            }
        }

        private void TestDrive()
        {
            startDriving = true;
            rightDir = true;
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if(startDriving == true)
            {
                //Will move the bus every set # of miliseconds
                velocity.X = 0;
                velocity.Y = 0;
                //Test for turning 
                if(time.Second%4 == 0)
                {
                    downDir= true;
                    if(time.Second%5 == 0)
                    {
                        rightDir = false;
                    }
                }
                //time.Millisecond % 100 == 0
                if (time.Second % 1 == 0)
                {
                    //Will move the bus sprite every other second
                    if (rightDir == true)
                    {
                        busImageIndex = 2;
                        velocity.X += busSpeed;
                        if (upDir == true)
                        {
                            busImageIndex = 7;
                            velocity.Y -= busSpeed;
                        }
                        else if (downDir == true)
                        {
                            busImageIndex = 4;
                            velocity.Y += busSpeed;
                        }
                        else
                        {
                            // busRect.X += busSpeed;
                        }
                        Console.WriteLine("Bus " + busRect.X + " " + busRect.Y);
                    }
                    if (leftDir == true)
                    {
                        busImageIndex = 3;
                        velocity.X -= busSpeed;
                        if (upDir == true)
                        {
                            busImageIndex = 6;
                            velocity.Y -= busSpeed;
                        }
                        else if (downDir == true)
                        {
                            busImageIndex = 5;
                            velocity.Y += busSpeed;
                        }
                        else
                        {
                            // busRect.X -= busSpeed;
                        }
                    }
                    if (upDir == true && leftDir == false && rightDir == false)
                    {
                        busImageIndex = 1;
                        velocity.Y -= busSpeed;
                    }
                    if (downDir == true && leftDir == false && rightDir == false)
                    {
                        busImageIndex = 0;
                        velocity.Y += busSpeed;
                    }
                    //busRect.Location = new Point(velocity.X + busRect.X, velocity.Y + busRect.Y);
                    currentPoint.X = velocity.X + busRect.X;
                    currentPoint.Y = velocity.Y + busRect.Y;
                }
                if(busRect.X >= Size.Width || busRect.Y >= Size.Height)
                {
                    startDriving = false;
                }
                else { }
                Invalidate();
            }
            
            
        }
    }
}
